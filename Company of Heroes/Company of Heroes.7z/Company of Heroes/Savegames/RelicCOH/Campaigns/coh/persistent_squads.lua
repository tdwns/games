PersistentSquads =  
{
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
					entry_1 = "slot_item\\allies_m18_recoilless_rifle",
					entry_0 = "slot_item\\allies_m18_recoilless_rifle",
				},
			},
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
					entry_1 = "slot_item\\allies_m18_recoilless_rifle",
					entry_0 = "slot_item\\allies_m18_recoilless_rifle",
				},
			},
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
					entry_1 = "slot_item\\allies_m18_recoilless_rifle",
					entry_0 = "slot_item\\allies_m18_recoilless_rifle",
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\airborne_infantry",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 2,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\engineer_infantry",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 1,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\engineer_infantry_sp_m01",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 2,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\heavy_machine_gun_section",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 2,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 1,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\mortar_section",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
					entry_0 = "slot_item\\allies_m9bazooka",
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\ranger_team",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
					entry_1 = "slot_item\\axis_panzerschreck",
					entry_0 = "slot_item\\axis_panzerschreck",
				},
			},
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\rifleman_squad",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\rifleman_squad_reinforcement",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 2,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 1,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\rifleman_squad_sp_m01",
	},
	 
	{
		squads =  
		{
			 
			{
				veterancy_rank = 3,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 2,
				slot_items =  
				{
				},
			},
			 
			{
				veterancy_rank = 2,
				slot_items =  
				{
				},
			},
		},
		sbp = "sbps\\races\\allies\\soldiers\\sniper_squad",
	},
	 
	{
		squads =  
		{
		},
		sbp = "sbps\\races\\allies\\vehicles\\jeep_squad",
	},
	 
	{
		squads =  
		{
		},
		sbp = "sbps\\races\\allies\\vehicles\\m10_tank_destroyer",
	},
	 
	{
		squads =  
		{
		},
		sbp = "sbps\\races\\allies\\vehicles\\m1_57mm_at_squad",
	},
	 
	{
		squads =  
		{
		},
		sbp = "sbps\\races\\allies\\vehicles\\m4_sherman_squad",
	},
	 
	{
		squads =  
		{
		},
		sbp = "sbps\\races\\allies\\vehicles\\m4_sherman_squad_crocodile",
	},
	 
	{
		squads =  
		{
		},
		sbp = "sbps\\races\\allies\\vehicles\\m8_greyhound_squad",
	},
}

