campaignid = "coh"
maxmission = 15
medals_awarded =  
{
	 
	{
		medal = "medals\\expert_infantryman_badge",
		mission = 0,
	},
	 
	{
		medal = "medals\\parachutist_badge",
		mission = 1,
	},
	 
	{
		medal = "medals\\bronze_star_m04",
		mission = 3,
	},
	 
	{
		medal = "medals\\distinguished_service_cross",
		mission = 4,
	},
	 
	{
		medal = "medals\\air_medal",
		mission = 6,
	},
	 
	{
		medal = "medals\\bronze_star_m08",
		mission = 7,
	},
	 
	{
		medal = "medals\\soldiers_medal",
		mission = 8,
	},
	 
	{
		medal = "medals\\distinguished_service_medal",
		mission = 10,
	},
	 
	{
		medal = "medals\\army_expert_badge",
		mission = 11,
	},
	 
	{
		medal = "medals\\silver_star_m14",
		mission = 12,
	},
	 
	{
		medal = "medals\\american_campaign_medal",
		mission = 10000,
	},
}
mostrecentsave = ""
scenario = 0
statename = "Invasion of Normandy"

