configuration =  
{
	 
	{
		setting = "window",
		value = 0,
		valueType = 1,
	},
	 
	{
		setting = "shadows",
		value = 2,
		valueType = 2,
	},
	 
	{
		setting = "postprocessing",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "squadcontrol",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "mousescroll",
		value = 128,
		valueType = 2,
	},
	 
	{
		setting = "ribbons",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "musicvolume",
		value = 255,
		valueType = 2,
	},
	 
	{
		setting = "unitresponses",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "modeldetail",
		value = 256,
		valueType = 2,
	},
	 
	{
		setting = "effectsfidelity",
		value = 3,
		valueType = 2,
	},
	 
	{
		setting = "texturedetail",
		value = 0,
		valueType = 2,
	},
	 
	{
		setting = "treedetail",
		value = 1,
		valueType = 2,
	},
	 
	{
		setting = "physics",
		value = 3,
		valueType = 2,
	},
	 
	{
		setting = "reflections",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "showgametime",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "sfxvolume",
		value = 255,
		valueType = 2,
	},
	 
	{
		setting = "objectscarring",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "width",
		value = 1024,
		valueType = 2,
	},
	 
	{
		setting = "soundfrequency",
		value = 44100,
		valueType = 2,
	},
	 
	{
		setting = "stickyselection",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "shrubsdetail",
		value = 1,
		valueType = 2,
	},
	 
	{
		setting = "shaderquality",
		value = 1,
		valueType = 2,
	},
	 
	{
		setting = "mastervolume",
		value = 255,
		valueType = 2,
	},
	 
	{
		setting = "screengamma",
		value = 3,
		valueType = 2,
	},
	 
	{
		setting = "soundconfig",
		value = 7,
		valueType = 2,
	},
	 
	{
		setting = "antialiasing",
		value = 0,
		valueType = 1,
	},
	 
	{
		setting = "height",
		value = 768,
		valueType = 2,
	},
	 
	{
		setting = "squadeventcues",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "modelquality",
		value = 1,
		valueType = 2,
	},
	 
	{
		setting = "effectsdensity",
		value = 2,
		valueType = 2,
	},
	 
	{
		setting = "helptext",
		value = 1,
		valueType = 1,
	},
	 
	{
		setting = "terraindetail",
		value = 1,
		valueType = 2,
	},
	 
	{
		setting = "speechvolume",
		value = 255,
		valueType = 2,
	},
	 
	{
		setting = "soundvoices",
		value = 96,
		valueType = 2,
	},
}
version = 1003

