Graphics =  
{
	TerrainDetail = 5,
}
Performance =  
{
	Avg_2_0 = 0.07354,
	Avg_2_1 = 0.10990,
	Avg_2_2 = 0,
	Avg_4_0 = 0.05773,
	Avg_4_1 = 0.12000,
	Avg_4_2 = 0.12000,
	Avg_8_0 = 0.07709,
	Avg_8_1 = 0.12000,
	Avg_8_2 = 0.12000,
	Max_2_0 = 0.08853,
	Max_2_1 = 2.35537,
	Max_2_2 = 0,
	Max_4_0 = 0.24596,
	Max_4_1 = 0.12000,
	Max_4_2 = 0.12000,
	Max_8_0 = 0.09025,
	Max_8_1 = 0.12000,
	Max_8_2 = 0.12000,
}
SCAR =  
{
}
SP_Skirmish =  
{
	skirmish_selectedmap = "8p_route_n13",
	start_location_index = 1,
	start_resources_index = 1,
	victory_ticker_index = 0,
	win_condition_index = 0,
}
SinglePlayer =  
{
	sp_campaign = "coh",
	sp_difficulty = 1,
	sp_selectedmap = "m16_chambois",
	sp_tutorial_popup_shown = "true",
}
Sound =  
{
	VolumeAmbient = 0.75000,
	VolumeMusic = 0.75000,
	VolumeSfx = 0.75000,
}

